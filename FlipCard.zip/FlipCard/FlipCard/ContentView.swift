import SwiftUI

struct Card: Identifiable {
    var id = UUID()
    var content: String
    var isFaceUp = false
    var isMatched = false
}

class CardGameViewModel: ObservableObject {
    @Published var cards: [Card] = []
    @Published var level: Int = 1
    @Published var isGameOver = false
    @Published var timeLeft: Int = 30
    @Published var score: Int = 0
    private var timer: Timer?
    private let baseCardContents = ["🍎", "🍌", "🍇", "🍓", "🍊", "🍉", "🍒", "🥝", "🍍", "🍑"]
    
    func startGame() {
        level = 1
        score = 0
        isGameOver = false
        setupCards(for: level)
        startTimer()
    }
    
    func nextLevel() {
        if level < 100 {
            level += 1
            score += timeLeft * 10
            setupCards(for: level)
            resetTimer()
        } else {
            endGame()
        }
    }
    
    private func setupCards(for level: Int) {
        let numberOfPairs = level + 1
        let requiredContent = generateCardContents(for: numberOfPairs)
        var newCards = requiredContent + requiredContent
        newCards.shuffle()
        cards = newCards.map { Card(content: $0) }
    }
    
    private func generateCardContents(for pairs: Int) -> [String] {
        if pairs <= baseCardContents.count {
            return Array(baseCardContents.prefix(pairs))
        } else {
            var generatedContents = baseCardContents
            while generatedContents.count < pairs {
                generatedContents += baseCardContents.map { "\($0)\(Int.random(in: 0...9))" }
            }
            return Array(generatedContents.prefix(pairs))
        }
    }
    
    func flipCard(card: Card) {
        guard let index = cards.firstIndex(where: { $0.id == card.id }),
              !cards[index].isFaceUp && !cards[index].isMatched else { return }
        
        withAnimation(.easeInOut(duration: 0.6)) {
            cards[index].isFaceUp.toggle()
        }
        
        checkForMatch()
    }
    
    private func checkForMatch() {
        let faceUpCards = cards.filter { $0.isFaceUp && !$0.isMatched }
        if faceUpCards.count == 2 {
            if faceUpCards[0].content == faceUpCards[1].content {
                matchCards(faceUpCards[0], faceUpCards[1])
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.resetFaceUpCards()
                }
            }
        }
    }
    
    private func matchCards(_ firstCard: Card, _ secondCard: Card) {
        cards.indices.forEach { index in
            if cards[index].id == firstCard.id || cards[index].id == secondCard.id {
                withAnimation(.easeInOut) {
                    cards[index].isMatched = true
                }
                score += 20
            }
        }
        checkLevelCompletion()
    }
    
    private func checkLevelCompletion() {
        if cards.allSatisfy({ $0.isMatched }) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.nextLevel()
            }
        }
    }
    
    private func resetFaceUpCards() {
        cards.indices.forEach { index in
            if cards[index].isFaceUp && !cards[index].isMatched {
                withAnimation(.easeInOut(duration: 0.6)) {
                    cards[index].isFaceUp = false
                }
            }
        }
    }
    
    private func startTimer() {
        timeLeft = 30
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if self.timeLeft > 0 {
                self.timeLeft -= 1
            } else {
                self.endGame()
            }
        }
    }
    
    private func resetTimer() {
        timer?.invalidate()
        startTimer()
    }
    
    private func endGame() {
        timer?.invalidate()
        isGameOver = true
    }
}

struct FlipCardGameView: View {
    @StateObject var viewModel = CardGameViewModel()
    
    var body: some View {
        VStack {
            if viewModel.isGameOver {
                VStack {
                    Text("🎉 Game Over! 🎉")
                        .font(.largeTitle)
                    Text("Score: \(viewModel.score)")
                        .font(.title2)
                        .padding()
                    Button("Restart Game") {
                        viewModel.startGame()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            } else {
                Text("Level \(viewModel.level)")
                    .font(.largeTitle)
                Text("Time Left: \(viewModel.timeLeft)s")
                    .font(.headline)
                    .foregroundColor(.red)
                Text("Score: \(viewModel.score)")
                    .font(.headline)
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 10) {
                    ForEach(viewModel.cards) { card in
                        CardView(card: card)
                            .onTapGesture {
                                viewModel.flipCard(card: card)
                            }
                    }
                }
                .padding()
            }
        }
        .onAppear {
            viewModel.startGame()
        }
        .padding()
    }
}

struct CardView: View {
    let card: Card
    
    var body: some View {
        ZStack {
            if card.isFaceUp || card.isMatched {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(radius: 5)
                RoundedRectangle(cornerRadius: 10)
                    .stroke(lineWidth: 2)
                Text(card.content)
                    .font(.largeTitle)
            } else {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.blue)
                    .shadow(radius: 5)
            }
        }
        .rotation3DEffect(
            .degrees(card.isFaceUp ? 0 : 180),
            axis: (x: 0, y: 1, z: 0)
        )
        .aspectRatio(2/3, contentMode: .fit)
        .animation(.easeInOut(duration: 0.6), value: card.isFaceUp)
    }
}

struct ContentView: View {
    var body: some View {
        FlipCardGameView()
    }
}

@main
struct FlipCardGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
