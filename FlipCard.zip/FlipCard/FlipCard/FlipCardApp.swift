//
//  FlipCardApp.swift
//  FlipCard
//
//  Created by Vishal S on 30/12/24.
//

import SwiftUI


struct FlipCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
